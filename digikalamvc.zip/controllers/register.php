<?php

class Register extends Controller{
    
    
    function __construct()
    {
    }
    
    function index(){
        $this->view('register/index');
    }

}


?>