

<style>
    .direct-access {
        width: 290px;
        height: 190px;
        display: block;
        float: right;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.19);
        margin-top: 10px;
        background: #fff;
        border-radius: 4px;
        overflow: hidden;
        margin-left: 10px;

    }
</style>

<a class="direct-access">

    <img src="public/images/direct-access1.jpg">

</a>

<a class="direct-access" style="width: 590px;margin-left: 0;">

    <img src="public/images/direct-access2.jpg">

</a>
<a class="direct-access">

    <img src="public/images/direct-access3.jpg">

</a>
<a class="direct-access">

    <img src="public/images/direct-access4.jpg">

</a>
<a class="direct-access" style="margin-left: 0;">

    <img src="public/images/direct-access5.jpg">

</a>

<a class="direct-access" style="width: 590px;">

    <img src="public/images/direct-access6.jpg">

</a>

<a class="direct-access" style="margin-left: 0;">

    <img src="public/images/direct-access7.jpg">

</a>

