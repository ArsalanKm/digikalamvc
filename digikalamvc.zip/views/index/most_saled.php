<div class="sliderscroll" style="margin-top: 12px;float: right;">

    <h3>
        پرفروش ترین کالاها
    </h3>

    <div class="sliderscroll_content">

        <div class="sliderscroll_prev">
            <span class="prev" onclick="sliderscroll('right',this);"></span>
        </div>
        <div class="sliderscroll_main">
            <ul>
                <li>
                    <a>

                        <img src="public/images/sliderscroll_1.jpg">

                        <img src="public/images/exclusive-blue.png">

                        <p class="yekan fontsm">
                            لپ تاپ سونی
                        </p>

                        <p class="yekan price">
                            1,200,000
                        </p>

                    </a>
                </li>
                <li>
                    <a>

                        <img src="public/images/scrollslider_2.jpg">

                        <img src="public/images/exclusive-blue.png">

                        <p class="yekan fontsm">
                            لپ تاپ acer
                        </p>

                        <p class="yekan price">
                            1,200,000
                        </p>

                    </a>
                </li>

                <li>
                    <a>

                        <img src="public/images/scrollslider_3.jpg">

                        <img src="public/images/exclusive-blue.png">

                        <p class="yekan fontsm">
                            لپ تاپ asus
                        </p>

                        <p class="yekan price">
                            1,200,000
                        </p>

                    </a>
                </li>

                <li>
                    <a>

                        <img src="public/images/scrollslider_4.jpg">

                        <img src="public/images/exclusive-blue.png">

                        <p class="yekan fontsm">
                            لپ تاپ
                            clicksite.ir
                        </p>

                        <p class="yekan price">
                            1,200,000
                        </p>

                    </a>
                </li>

                <li>
                    <a>

                        <img src="public/images/scrollslider_5.jpg">

                        <img src="public/images/exclusive-blue.png">

                        <p class="yekan fontsm">
                            لپ تاپ
                            Lenovo
                        </p>

                        <p class="yekan price">
                            1,200,000
                        </p>

                    </a>
                </li>

            </ul>

        </div>

        <div class="sliderscroll_next">
            <span class="next" onclick="sliderscroll('left',this);"></span>
        </div>

    </div>

</div>
