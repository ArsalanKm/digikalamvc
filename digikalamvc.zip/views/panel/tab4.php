<section>
    <table cellspacing="0">
        <tr>
            <td>ردیف</td>
            <td>تاریخ</td>
            <td>کالا</td>
            <td>می پسندم</td>
            <td>مشاهده</td>
            <td>ویرایش</td>
            <td>حذف</td>

        </tr>

        <tr>
            <td>1</td>
            <td>تیرماه 1300</td>
            <td>لپ تاپ سونی</td>
            <td>10</td>
            <td><img src="public/images/View.gif"></td>
            <td><img src="public/images/Edit.gif"></td>
            <td><img src="public/images/Delete.gif"></td>

        </tr>

    </table>
</section>