<style>
    .page_navigator {
        padding: 0;
        float: right;
        width: 100%;

    }

    .page_navigator li {

        font-size: 9pt;
        float: right;
        margin-left: 15px;
    }

    .page_navigator li img {

        margin-right: 4px;
    }
</style>

<ul class="page_navigator">
    <li class="yekan">

        جست و جوی کالا
        <img src="public/images/patharrow.png">
    </li>

    <li class="yekan">

        کالای دیجیتال
        <img src="public/images/patharrow.png">
    </li>
    <li class="yekan">

        موبایل
        <img src="public/images/patharrow.png">
    </li>
    <li class="yekan">

        گوشی موبایل
        <img src="public/images/patharrow.png">
    </li>
    <li class="yekan">

        1200
        نتیجه
        <img src="public/images/patharrow.png">
    </li>
</ul>
