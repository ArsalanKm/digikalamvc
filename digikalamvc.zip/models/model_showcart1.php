<?php

class model_showcart1 extends Model{

    function __construct()
    {
        parent::__construct();
    }

    


}


?>