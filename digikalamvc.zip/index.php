<?php

require ('core/app.php');
require ('core/controller.php');
require ('core/model.php');
require ('core/config.php');
require ('core/payment.php');



new App;


?>