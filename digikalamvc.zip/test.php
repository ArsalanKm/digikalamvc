<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="public/js/jquery-3.0.0.min.js"></script>
</head>
<body>

<script>

    var data =[];
    var name='attr-1';

    data.push({'name':name , 'value': 10});

    $.each(data,function(key,val){
        if(val['name']=)
        console.log(val);
    });



    $.post('test2.php', data, function (msg) {

    }, 'json');
</script>

</body>
</html>


function getChildren($parentId = 0)
{
$sql = "select * from tbl_category where parent=?";
$result = $this->doSelect($sql, [$parentId]);
return $result;

}

function getMenu($parentId = 0)
{

$list = $this->getChildren($parentId);

foreach ($list as $key => $item) {
$chidren = $this->getChildren($item['id']);
$list[$key]['children'] = $chidren;

array_push($this->MenuTotal, $list[$key]);
if (sizeof($chidren) > 0) {

$this->getMenu($item['id']);

}
}


}